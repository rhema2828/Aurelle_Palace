const loader = document.getElementById("loader");
window.addEventListener("load", () => setTimeout(() => loader.classList.add("done"), 700));

document.getElementById("year").textContent = new Date().getFullYear();

const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => revealObserver.observe(item));
} else {
  revealItems.forEach(item => item.classList.add("visible"));
}

const menu = document.getElementById("menuOverlay");
const menuToggle = document.getElementById("menuToggle");
const closeMenu = document.getElementById("closeMenu");
function setMenu(open) {
  menu.classList.toggle("open", open);
  menuToggle.setAttribute("aria-expanded", String(open));
  document.body.classList.toggle("locked", open);
}
menuToggle.addEventListener("click", () => setMenu(true));
closeMenu.addEventListener("click", () => setMenu(false));
menu.querySelectorAll("a").forEach(link => link.addEventListener("click", () => setMenu(false)));

const booking = document.getElementById("booking");
function openBooking() {
  setMenu(false);
  booking.classList.add("open");
  booking.setAttribute("aria-hidden", "false");
  document.body.classList.add("locked");
  setTimeout(() => document.getElementById("guestName").focus(), 350);
}
function closeBooking() {
  booking.classList.remove("open");
  booking.setAttribute("aria-hidden", "true");
  document.body.classList.remove("locked");
}
document.querySelectorAll("[data-book]").forEach(button => button.addEventListener("click", event => {
  event.preventDefault();
  openBooking();
}));
document.querySelectorAll("[data-close-booking]").forEach(button => button.addEventListener("click", closeBooking));
document.addEventListener("keydown", event => {
  if (event.key === "Escape") { closeBooking(); closeRoomDetails(); setMenu(false); }
});

const arrival = document.getElementById("arrival");
const departure = document.getElementById("departure");
const today = new Date();
const localISODate = date => {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60000).toISOString().slice(0, 10);
};
arrival.min = localISODate(today);
departure.min = localISODate(today);
arrival.addEventListener("change", () => {
  departure.min = arrival.value || localISODate(today);
  if (departure.value && departure.value <= arrival.value) departure.value = "";
});

document.getElementById("bookingForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  if (form.get("departure") <= form.get("arrival")) {
    document.getElementById("formMessage").textContent = "Please choose a departure date after your arrival.";
    return;
  }
  document.getElementById("formMessage").textContent =
    `Thank you, ${form.get("name")} — your sample enquiry is ready. This demo does not send data or create a real booking.`;
  event.currentTarget.reset();
  arrival.min = localISODate(new Date());
  departure.min = localISODate(new Date());
});


// Room details: the villa arrow opens room information first, not the booking form.
const roomModal = document.getElementById("roomModal");
const roomData = {
  beach: {
    eyebrow: "BAREFOOT LUXURY · BEACHFRONT",
    title: "The Beach Residence",
    intro: "Step from a private tropical garden onto soft white sand. Generous indoor-outdoor living and a secluded pool make this an easygoing hideaway for families or friends.",
    summary: "Beachfront · Private pool & garden · 2–4 guests",
    images: [
      ["https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1100&q=85", "Residence with pool"],
      ["https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=800&q=85", "Private tropical villa"],
      ["https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=85", "Airy villa interior"]
    ],
    features: [["⌂", "Space to unwind", "Separate lounge and bedroom areas"], ["♧", "Private garden", "Tropical greenery and outdoor lounging"], ["◉", "Your own pool", "A secluded pool beside the residence"], ["♧", "Steps to the beach", "Easy access to sand and lagoon"]]
  },
  ocean: {
    eyebrow: "OVERWATER ESCAPE · LAGOON VIEWS",
    title: "The Ocean Villa",
    intro: "Float above luminous turquoise water, with a sun-soaked deck and uninterrupted lagoon views. Slow mornings and sunset swims are part of the rhythm here.",
    summary: "Overwater · Private deck · 2 guests",
    images: [
      ["https://images.unsplash.com/photo-1573843981267-be1999ff37cd?auto=format&fit=crop&w=1100&q=85", "Overwater villa above lagoon"],
      ["https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=800&q=85", "Private pool and sun deck"],
      ["https://images.unsplash.com/photo-1602002418082-a4443e081dd1?auto=format&fit=crop&w=800&q=85", "Warm luxury suite interior"]
    ],
    features: [["⌂", "Ocean-facing suite", "Open, airy interiors with lagoon views"], ["☼", "Private sun deck", "Space for slow mornings and sunset"], ["≈", "Direct lagoon access", "Step down for a swim in the sea"], ["♡", "Ideal for two", "A secluded escape for couples"]]
  }
};
let selectedRoom = "ocean";
function showRoomDetails(key) {
  const room = roomData[key];
  if (!room) return;
  selectedRoom = key;
  document.getElementById("roomEyebrow").textContent = room.eyebrow;
  document.getElementById("roomTitle").textContent = room.title;
  document.getElementById("roomIntro").textContent = room.intro;
  document.getElementById("roomSummary").textContent = room.summary;
  document.getElementById("roomGallery").innerHTML = room.images.map(([src, alt]) => `<img src="${src}" alt="${alt}" loading="lazy">`).join("");
  document.getElementById("roomFeatures").innerHTML = room.features.map(([icon, title, desc]) => `<div class="room-feature"><span class="room-feature-icon">${icon}</span><div><strong>${title}</strong><span>${desc}</span></div></div>`).join("");
  roomModal.classList.add("open");
  roomModal.setAttribute("aria-hidden", "false");
  document.body.classList.add("locked");
}
function closeRoomDetails() {
  roomModal.classList.remove("open");
  roomModal.setAttribute("aria-hidden", "true");
  if (!booking.classList.contains("open") && !menu.classList.contains("open")) document.body.classList.remove("locked");
}
document.querySelectorAll("[data-room]").forEach(button => button.addEventListener("click", () => showRoomDetails(button.dataset.room)));
document.querySelectorAll("[data-close-room]").forEach(button => button.addEventListener("click", closeRoomDetails));
document.getElementById("roomBookButton").addEventListener("click", () => {
  closeRoomDetails();
  openBooking();
  const stayType = document.getElementById("stayType");
  stayType.value = selectedRoom === "beach" ? "Beach Residence" : "Ocean Villa";
});

// Beachy scroll polish: a soft glimmer follows the scroll position and a few bubbles drift upward.
(() => {
  const glimmer = document.createElement('div');
  glimmer.id = 'sea-glimmer';
  document.body.appendChild(glimmer);
  let glimmerTimer;
  window.addEventListener('scroll', () => {
    glimmer.style.top = `${Math.max(0, Math.min(window.innerHeight - 3, window.innerHeight * 0.22))}px`;
    glimmer.classList.add('active');
    clearTimeout(glimmerTimer);
    glimmerTimer = setTimeout(() => glimmer.classList.remove('active'), 420);
  }, { passive: true });

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reducedMotion) {
    let lastBubble = 0;
    window.addEventListener('scroll', () => {
      const now = Date.now();
      if (now - lastBubble < 850 || Math.random() > 0.55) return;
      lastBubble = now;
      const bubble = document.createElement('span');
      bubble.className = 'sea-bubble';
      bubble.style.left = `${8 + Math.random() * 84}%`;
      const size = 4 + Math.random() * 9;
      bubble.style.width = `${size}px`;
      bubble.style.height = `${size}px`;
      bubble.style.animationDuration = `${4.5 + Math.random() * 3}s`;
      document.body.appendChild(bubble);
      bubble.addEventListener('animationend', () => bubble.remove(), { once: true });
    }, { passive: true });
  }
})();


// Ambient bubbles rise through the hero like champagne bubbles underwater.
const bubbleField=document.getElementById('bubbleField');
const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function spawnBubble(){
  if(!bubbleField||reducedMotion||document.hidden)return;
  const b=document.createElement('span');b.className='bubble';
  const size=4+Math.random()*15;b.style.width=size+'px';b.style.height=size+'px';
  b.style.left=(Math.random()*100)+'%';b.style.setProperty('--duration',(7+Math.random()*8)+'s');
  b.style.setProperty('--sway',Math.round(Math.random()*60-30)+'px');b.style.setProperty('--opacity',(0.18+Math.random()*0.35));
  bubbleField.appendChild(b);b.addEventListener('animationend',()=>b.remove(),{once:true});
}
if(bubbleField&&!reducedMotion){for(let i=0;i<20;i++)setTimeout(spawnBubble,i*180);setInterval(spawnBubble,420)}

// Soft pointer ripples, desktop only.
const heroSurface=document.querySelector('.hero');const rippleLayer=document.getElementById('cursorRipples');let lastRipple=0;
heroSurface?.addEventListener('pointermove',e=>{
  if(reducedMotion||!rippleLayer||e.pointerType==='touch'||performance.now()-lastRipple<180)return;
  lastRipple=performance.now();const rect=heroSurface.getBoundingClientRect();const r=document.createElement('span');r.className='cursor-ripple';
  r.style.left=(e.clientX-rect.left)+'px';r.style.top=(e.clientY-rect.top)+'px';rippleLayer.appendChild(r);r.addEventListener('animationend',()=>r.remove(),{once:true});
});

// On scroll, the hero copy gently dissolves and an aqua wash blends into the next scene.
const waterTransition=document.getElementById('waterTransition');const heroCopy=document.querySelector('.hero-content');let scrollFrame=false;
function updateOceanTransition(){
 if(!heroSurface||!waterTransition||!heroCopy)return;
 const rect=heroSurface.getBoundingClientRect();const progress=Math.min(1,Math.max(0,-rect.top/Math.max(1,rect.height*.72)));
 heroCopy.style.opacity=String(1-progress*.96);heroCopy.style.filter='blur('+(progress*7)+'px)';
 waterTransition.classList.toggle('active',progress>.48&&progress<1);scrollFrame=false;
}
window.addEventListener('scroll',()=>{if(!scrollFrame){requestAnimationFrame(updateOceanTransition);scrollFrame=true}},{passive:true});


// Click-to-open dropdowns for Dining and Wellness.
document.querySelectorAll('.nav-dropdown').forEach(drop => {
  const trigger = drop.querySelector('.nav-drop-trigger');
  trigger.addEventListener('click', event => {
    event.stopPropagation();
    const willOpen = !drop.classList.contains('open');
    document.querySelectorAll('.nav-dropdown').forEach(other => { other.classList.remove('open'); other.querySelector('.nav-drop-trigger').setAttribute('aria-expanded','false'); });
    drop.classList.toggle('open', willOpen);
    trigger.setAttribute('aria-expanded', String(willOpen));
  });
  drop.querySelectorAll('.nav-drop-panel a').forEach(link => link.addEventListener('click', () => {
    drop.classList.remove('open'); trigger.setAttribute('aria-expanded','false');
  }));
});
document.addEventListener('click', () => document.querySelectorAll('.nav-dropdown').forEach(drop => { drop.classList.remove('open'); drop.querySelector('.nav-drop-trigger').setAttribute('aria-expanded','false'); }));
window.addEventListener('scroll', () => document.body.classList.toggle('at-top', window.scrollY < 20), {passive:true});
document.body.classList.toggle('at-top', window.scrollY < 20);


// The Explore Dining and Explore Wellness buttons open their own inline menus.
document.querySelectorAll('.explore-toggle').forEach(button => {
  button.addEventListener('click', () => {
    const panel = document.getElementById(button.getAttribute('aria-controls'));
    const willOpen = button.getAttribute('aria-expanded') !== 'true';
    button.setAttribute('aria-expanded', String(willOpen));
    if (panel) panel.hidden = !willOpen;
  });
});
